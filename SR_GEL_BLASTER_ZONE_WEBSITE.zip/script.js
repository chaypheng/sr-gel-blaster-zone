const products = [
  {name:"SR-15 V2 Hobby Blaster",price:199,badge:"NEW",rating:"★★★★★"},
  {name:"M4A1 Full Metal Style",price:169,badge:"HOT",rating:"★★★★★"},
  {name:"Glock 18C Electric Style",price:89,badge:"NEW",rating:"★★★★☆"},
  {name:"1500 Rounds Drum Mag",price:35,badge:"",rating:"★★★★☆"},
  {name:"11.1V 2200mAh Battery",price:25,badge:"",rating:"★★★★☆"}
];

const productBox = document.getElementById("products");
productBox.innerHTML = products.map((p,i)=>`
  <article class="product">
    ${p.badge ? `<span class="badge">${p.badge}</span>` : ""}
    <div class="pic">${["SR-15","M4A1","G18C","1500","11.1V"][i]}</div>
    <h3>${p.name}</h3>
    <div class="price">$${p.price.toFixed(2)}</div>
    <div class="stars">${p.rating}</div>
    <button class="add" onclick="addToCart('${p.name.replaceAll("'","\\'")}')">🛒 ADD TO CART</button>
  </article>
`).join("");

let cart = 0;
function addToCart(name){
  cart++;
  document.getElementById("cartCount").textContent = cart;
  showToast(`${name} added to cart`);
}
function showToast(text){
  const toast=document.getElementById("toast");
  toast.textContent=text;
  toast.classList.add("show");
  setTimeout(()=>toast.classList.remove("show"),1800);
}
function subscribe(e){
  e.preventDefault();
  showToast("Thanks for subscribing!");
  e.target.reset();
}
document.querySelector(".menu-toggle").addEventListener("click",()=>{
  document.querySelector(".header nav").classList.toggle("open");
});
document.querySelectorAll(".header nav a").forEach(a=>a.addEventListener("click",()=>{
  document.querySelector(".header nav").classList.remove("open");
}));
